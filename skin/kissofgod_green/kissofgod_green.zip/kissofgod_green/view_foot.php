<?=$hide_prev_start?>
<table border=0 width=<?=$width?> cellspacing=0 cellpadding=0><tr><td width=1><img src=<?=$dir?>/t.gif border=0 width=1 height=1></td><td class=kissofgod-line><img src=<?=$dir?>/t.gif height=1></td><td width=1><img src=<?=$dir?>/t.gif border=0 width=1 height=1></td></tr></table>
<table border=0 width=<?=$width?> cellspacing=0 cellpadding=0>
<col width=1></col><col width=50></col><col></col><col width=80></col><col width=1></col>
<tr align=center>
  <td width=1>&nbsp;</td>
  <td width=50 style='word-break:break-all;font-family:tahoma;font-size:8pt'>��prev</td>
  <td align=left style='word-break:break-all;'>&nbsp; <?=$a_prev?><?=$prev_subject?></a></td>
  <td width=80 nowrap><?=$prev_face_image?> <?=$prev_name?></td>
  <td width=1>&nbsp;</td>
</tr>
</table>
<?=$hide_prev_end?>

<?=$hide_next_start?>
<table border=0 width=<?=$width?> cellspacing=0 cellpadding=0><tr><td width=1><img src=<?=$dir?>/t.gif border=0 width=1 height=1></td><td class=kissofgod-line><img src=images/t.gif height=1></td><td width=1><img src=<?=$dir?>/t.gif border=0 width=1 height=1></td></tr></table>
<table border=0 width=<?=$width?> cellspacing=0 cellpadding=0>
<col width=1></col><col width=50></col><col width=></col><col width=80></col><col width=1></col>
<tr align=center>
  <td width=1>&nbsp;</td>
  <td width=50 style='word-break:break-all;font-family:tahoma;font-size:8pt'>��next</td>
  <td align=left style='word-break:break-all;'>&nbsp; <?=$a_next?><?=$next_subject?></a></td>
  <td width=80 nowrap><?=$next_face_image?> <?=$next_name?></td>
  <td width=1>&nbsp;</td>
</tr>
</table>

<?=$hide_next_end?>
<table border=0 width=<?=$width?> cellspacing=0 cellpadding=0>
<tr>
 <td colspan=3 class=kissofgod-base-listline></td>
</tr>
</table>

<!-- ��ư ���� ��� -->
<table border=0 cellspacing=0 cellpadding=0 width=<?=$width?>>
<tr>
 <td width=1><img src=<?=$dir?>/t.gif border=0 width=1 height=1></td>
 <td class=kissofgod-button-font>
    <?=$a_list?>&nbsp;List&nbsp;</a>
    <?=$a_write?>&nbsp;Write&nbsp;</a>
 </td>
 <td align=right class=kissofgod-button-font>
    <?=$a_modify?>&nbsp;Edit&nbsp;</a>
    <?=$a_delete?>&nbsp;Del&nbsp;</a>
    <?=$a_reply?>&nbsp;Reply&nbsp;</a>
 </td>
 <td width=1><img src=<?=$dir?>/t.gif border=0 width=1 height=1></td>
</tr>
</table>
<br><br><br>
