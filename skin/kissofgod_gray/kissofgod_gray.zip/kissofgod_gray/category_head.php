<div align=center>

<img src=images/t.gif border=0 width=100 height=1><br>
<Table border=0 width=100% cellspacing=0 cellpadding=0>
<tr>
  <td nowrap valign=top align=center width=100%><?=$a_c_list?><font style=font-family:tahoma;font-size:8pt>Category (<?=$setup[total_article]?>)</font></a></td>
</tr>
</table>

