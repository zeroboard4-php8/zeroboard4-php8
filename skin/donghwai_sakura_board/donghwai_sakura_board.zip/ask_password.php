<br><br><br><table border="0" cellpadding="0" cellspacing="0" width="300" align="center">
<tr><form method=post name=delete action=<?=$target?>>
<input type=hidden name=page value=<?=$page?>>
<input type=hidden name=id value=<?=$id?>>
<input type=hidden name=no value=<?=$no?>>
<input type=hidden name=select_arrange value=<?=$select_arrange?>>
<input type=hidden name=desc value=<?=$desc?>>
<input type=hidden name=page_num value=<?=$page_num?>>
<input type=hidden name=keyword value="<?=$keyword?>">
<input type=hidden name=category value="<?=$category?>">
<input type=hidden name=sn value="<?=$sn?>">
<input type=hidden name=ss value="<?=$ss?>">
<input type=hidden name=sc value="<?=$sc?>">
<input type=hidden name=mode value="<?=$mode?>">
<input type=hidden name=c_no value=<?=$c_no?>><td width="1" height="5"><img src="<?=$dir?>/bg2.gif" width="1" height="5" border="0"></td>
<td width="298" height="5" background="<?=$dir?>/bg1.gif"><img src="<?=$dir?>/t.gif" width="1" height="1" border="0"></td>
<td width="1" height="5"><img src="<?=$dir?>/bg2.gif" width="1" height="5" border="0"></td></tr><tr>
<td width="1" height="5"></td>
<td width="284" align="center" height="78" valign="middle" style="background-image:url('<?=$dir?>/bg.gif'); background-repeat:repeat-y; background-attachment:fixed; background-position:90px 0px; padding:5px;"><span class=v81><?=$title?><br><?=$input_password?></span></td>
<td width="1" height="5"></td></tr>
<tr><td width="1" height="5"><img src="<?=$dir?>/bg2.gif" width="1" height="5" border="0"></td>
<td width="298" height="5" background="<?=$dir?>/bg1.gif"><img src="<?=$dir?>/t.gif" width="1" height="1" border="0"></td>
<td width="1" height="5"><img src="<?=$dir?>/bg2.gif" width="1" height="5" border="0"></td></tr></table>

<table border="0" cellpadding="3" cellspacing="0" align="center" width=300>
<tr><td align="center"><input type=submit value="ENTER" class=submit>
<input type=button value="BACK" class=submit onclick=history.back()></td></form></tr></table>