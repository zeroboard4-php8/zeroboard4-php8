<br><br><br><table border="0" cellpadding="0" cellspacing="0" width="300" align="center">
<tr><td width="1" height="5"><img src="<?=$dir?>/bg2.gif" width="1" height="5" border="0"></td>
<td width="298" height="5" background="<?=$dir?>/bg1.gif"><img src="t.gif" width="1" height="1" border="0"></td>
<td width="1" height="5"><img src="<?=$dir?>/bg2.gif" width="1" height="5" border="0"></td></tr>
<tr><td width="1" height="5"></td>
<td width="284" style="padding:5px;">
<table border="0" cellpadding="0" cellspacing="0" width="298" height="78">
<tr><td width="124" background="<?=$dir?>/bg.gif" align="right" height="78">
<span class=v81>*id&nbsp;<br>
*PASSWORD&nbsp;</span></td>
<td height="78">
<input type=text name=user_id size=20 maxlength=20 class=input><br>
<input type=password name=password size=20 maxlength=20 class=input></td></tr></table></td><td width="1" height="5"></td></tr><tr>
<td width="1" height="5"><img src="<?=$dir?>/bg2.gif" width="1" height="5" border="0"></td>
<td width="298" height="5" background="<?=$dir?>/bg1.gif"><img src="t.gif" width="1" height="1" border="0"></td>
<td width="1" height="5"><img src="<?=$dir?>/bg2.gif" width="1" height="5" border="0"></td></tr></table>

<table border="0" cellpadding="3" cellspacing="0" align="center" width=300>
<tr><td align="center"><input type=submit value="LOGIN" class=submit> <input type=button value="BACK" class=submit onclick=history.back()>&nbsp;&nbsp;</a></td></tr></table>