<table border="0" cellpadding="0" cellspacing="0" background="<?=$dir?>/dot.gif" align="center" width=<?=$width?>>
<tr><td height="1"><img src="<?=$dir?>/t.gif" width="1" height="1" border="0"></td></tr></table>

<table border="0" cellpadding="3" cellspacing="0" align="center" width=<?=$width?>>
<tr><td valign="top" align="left">
<span class=v91><img align="absmiddle" src="<?=$dir?>/img_1.gif" width="17" height="18" border="0"><?=$a_list?>����Ʈ</a> &nbsp;<?=$a_write?>�۾���</a></span>
</td><td align="right">
<span class=v91><img align="absmiddle" src="<?=$dir?>/img_2.gif" width="17" height="18" border="0"><?=$a_reply?>�亯</a> &nbsp;<?=$a_modify?>����</a> &nbsp;<?=$a_delete?>����</a></span>
</td></tr></table>

<table border="0" cellpadding="0" cellspacing="0" align="center" width=<?=$width?>>
<tr><td height="10"><img src="<?=$dir?>/t.gif" width="1" height="10" border="0"></td></tr></table>