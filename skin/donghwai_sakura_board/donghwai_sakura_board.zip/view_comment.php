<table border="0" cellpadding="5" cellspacing="0" align="center" width=<?=$width?>>
<tr><td valign="top">
<table border="0" cellpadding="0" cellspacing="0" width="98%" align="center">
<tr><td valign="top" style="padding:5px;" width="120">
<p align="right"><span class=v91><?=$c_face_image?><?=$comment_name?></b></span><br><span class=v71>(<?=$c_reg_date?><?=$a_del?>,delete</a>)</span>
</td><td width="5" valign="top" bgcolor="#F0F0F0"><img src="t.gif" width="5" height="5" border="0"></td>
<td valign="middle" style="padding:5px;"><span class=v91><?=$c_memo?></span></p></td></tr></table></td></tr></table>
<table border="0" cellpadding="0" cellspacing="0" background="<?=$dir?>/dot.gif" align="center" width=<?=$width?>>
<tr><td height="1"><img src="<?=$dir?>/t.gif" width="1" height="1" border="0"></td></tr></table>