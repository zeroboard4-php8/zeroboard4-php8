</table>

<?
 if($setup[use_category]&& $use_view_list_skin)
 {
?>
 </td>
</tr>
</table>
<?}?>

