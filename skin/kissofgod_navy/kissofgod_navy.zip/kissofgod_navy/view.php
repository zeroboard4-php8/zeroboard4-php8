<img src=images/t.gif border=0 height=4><br>
<table border=0 cellspacing=0 cellpadding=0 width=<?=$width?>>
<tr>
 <td colspan=3 class=kissofgod-base-listline></td>
</tr>
<tr>
 <td><img src=<?=$dir?>/search_left.gif border=0 width=1></td>
 <td valign=top>

<table border=0 cellspacing=0 cellpadding=0 width=100%>
<tr style=padding:5>
 <td colspan=2 nowrap style='padding-left:10'><?=$face_image?><span style='font-family:Tahoma; font-weight:bold'><?=$name?></span>��<?=$hide_homepage_start?><span style='font-family:Tahoma; font-size:8pt'><?=$homepage?></span><?=$hide_homepage_end?></td>
</tr>

<?=$hide_download1_start?>
<tr style=padding:5>
 <td align=right nowrap style='font-family:Tahoma; font-weight:bold'>�ٿ�ε� #1 &nbsp;&nbsp;</td>
 <td ><?=$a_file_link1?><?=$file_name1?> (<?=$file_size1?>)</a>, Download : <?=$file_download1?></td>
</tr>

<tr>
 <td height=1 colspan=2 class=kissofgod-line><img src=<?=$dir?>/t.gif border=0 width=1 height=1></td>
</tr>

<?=$hide_download1_end?>

<?=$hide_download2_start?>
<tr style=padding:5>
 <td align=right nowrap style='font-family:Tahoma; font-weight:bold'>�ٿ�ε� #2 &nbsp;&nbsp;</td>
 <td ><?=$a_file_link2?><?=$file_name2?> (<?=$file_size2?>)</a>, Download : <?=$file_download2?></td>
</tr>

<tr>
 <td height=1 colspan=2 class=kissofgod-line><img src=<?=$dir?>/t.gif border=0 width=1 height=1></td>
</tr>

<?=$hide_download2_end?>

<?=$hide_sitelink1_start?>
<tr style=padding:5>
 <td align=right style='font-family:Tahoma; font-weight:bold'>��ũ #1 &nbsp;&nbsp;</td>
 <td><?=$sitelink1?></td>
</tr>

<tr>
 <td height=1 colspan=2 class=kissofgod-line><img src=<?=$dir?>/t.gif border=0 width=1 height=1></td>
</tr>

<?=$hide_sitelink1_end?>

<?=$hide_sitelink2_start?>
<tr style=padding:5>
 <td align=right style='font-family:Tahoma; font-weight:bold'>��ũ #2 &nbsp;&nbsp;</td>
 <td ><?=$sitelink2?></td>
</tr>

<tr>
 <td height=1 colspan=2 class=kissofgod-line><img src=<?=$dir?>/t.gif border=0 width=1 height=1></td>
</tr>

<?=$hide_sitelink2_end?>

<tr style=padding:5>
 <td colspan=2 style='word-break:break-all;padding:20 10 10 10'><b><?=$subject?></b></td>
</tr>

<tr style=padding:5>
 <td colspan=2 style='word-break:break-all;padding:10' height=80 >
     <span style=line-height:160%>
     <?=$upload_image1?>
     <?=$upload_image2?>
     <?=$memo?>
     <br>
     <div align=right style=font-family:tahoma;font-size=8pt><?=$ip?></div>
<br>
     </span>
 </td>
</tr>
</table>

  </td>
  <Td width=1><img src=<?=$dir?>/search_left.gif border=0 width=1></td>
</tr>
</table>

<!-- ������ ��� �����ϴ� �κ� -->
<?=$hide_comment_start?> 
<Br>

<table border=0 cellspacing=0 cellpadding=0 width=<?=$width?>>
<col width=1></col><col width=80></col><col></col><col width=50></col><col width=20></col><col width=1></col>
