<tr align=center>
  <td width=1><img src=<?=$dir?>/t.gif border=0 width=1 height=1></td>
  <td nowrap><font style=font-family:matchworks,tahoma;font-size:7pt><?=$number?></td>
  <td align=left style='word-break:break-all;'>&nbsp; <?=$insert?><?=$icon?><?=$subject?> <font size=1><?=$comment_num?></font></td> 
  <td nowrap><?=$face_image?>&nbsp;&nbsp;<?=$name?>&nbsp;&nbsp;</div></td>
  <td nowrap><font style=font-family:tahoma;font-size:8pt>&nbsp;<?=$reg_date?>&nbsp;</td>
  <td nowrap><font style=font-family:tahoma;font-size:8pt><?=$hit?></td>
  <td width=1><img src=<?=$dir?>/t.gif border=0 width=1></td>
</tr>
<tr>
  <td><img src=<?=$dir?>/t.gif border=0 with=1></td>
  <td height=1 colspan=5 class=kissofgod-line><img src=<?=$dir?>/t.gif border=0 width=100% height=1></td>
  <td><img src=<?=$dir?>/t.gif border=0 width=1></td>
</tr>
