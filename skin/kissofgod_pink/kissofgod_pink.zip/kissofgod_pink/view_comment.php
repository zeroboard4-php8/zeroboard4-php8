<tr valign=top onMouseOver=this.style.backgroundColor='#FFF5F5' onMouseOut=this.style.backgroundColor=''>
    <td width=15>&nbsp;</td>
    <td nowrap width=80><?=$c_face_image?> <?=$comment_name?></td>
    <td style='word-break:break-all;'><?=nl2br($c_memo)?></td>
    <td width=50 nowrap style=font-family:tahoma;font-size:7pt><?=$c_reg_date?></td>
    <td width=20 align=right style=font-family:verdana;font-size:9px;><?=$a_del?>x</a><img src=<?=$dir?>/t.gif border=0 width=1 height=1></td>
    <td width=10><img src=<?=$dir?>/t.gif border=0 width=1 height=1></td>
</tr>
<tr>
    <td height=3 colspan=6><img src=<?=$dir?>/t.gif border=0 height=3></td>
</tr>
