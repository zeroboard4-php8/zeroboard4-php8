<div align=center>
<br><br><br>
<table border=0 width=250>
<tr>
  <td colspan=2 align=center><span class=kissofgod-bold-font>MEMBER LOGIN</span></td>
</tr>
<tr>
 <td colspan=2 class=kissofgod-base-line></td>
</tr>
<tr>
  <td colspan=2 height=10><img src=<?=$dir?>/t.gif border=0 width=1 height=1></td>
</tr>
<tr>
  <td align=right>ID��</td>
  <td><input type=text name=user_id size=10 maxlength=20 class=input></td>
</tr>
<tr>
  <td align=right>Password��</td>
  <td><input type=password name=password size=10 maxlength=20 class=input></td>
</tr>
<tr height=30>
  <td align=center align=center colspan=2 >
      <br>
     <input type=submit value="Ok~!" class=kissofgod-submit>��
     <input type=button value="Back" onclick=history.go(-1) class=kissofgod-submit>
  </td>
</tr>
<tr>
 <td colspan=2 class=kissofgod-base-line></td>
</tr>
</table>
