<tr align=center height=20 onMouseOver=this.style.backgroundColor='#FFF5F5' onMouseOut=this.style.backgroundColor=''>
  <td><img src=<?=$dir?>/t.gif border=0 width=1></td>
  <?=$hide_cart_start?><td><input type=checkbox name=cart value="<?=$data[no]?>"></td><?=$hide_cart_end?>
  <td nowrap><font style=font-size:8pt;font-family:tahoma><?=$number?></font></td>
  <td align=left style='word-break:break-all;'><?=$insert?><?=$icon?><?=$subject?> <font style=font-family:tahoma;font-size:7pt><?=$comment_num?></font></td> 
  <td nowrap><?=$face_image?>&nbsp;<font style='font-weight:normal'><?=$name?></font>&nbsp;</div></td>
  <td nowrap><font style=font-family:tahoma;font-size:8pt>&nbsp;<?=$reg_date?>&nbsp;</td>
  <td nowrap><font style=font-family:tahoma;font-size:8pt><?=$hit?></td>
  <td><img src=<?=$dir?>/t.gif border=0 width=1></td>
</tr>

<tr>
  <td width=1 class=kissofgod-line><img src=<?=$dir?>/t.gif border=0 width=1 height=1></td>
  <td height=1 colspan=<?=$colnum?> class=kissofgod-line><img src=<?=$dir?>/t.gif border=0 width=1 height=1></td>
  <td width=1 class=kissofgod-line><img src=<?=$dir?>/t.gif border=0 width=1 height=1></td>
</tr>
